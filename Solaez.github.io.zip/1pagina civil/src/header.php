<header class="header1">
      <div class="header-container">
          <a href="/index.php" class="logo">
              <img src="/1pagina civil/img/iconos/LOGO hd.png" alt="Logo">
          </a>
          <nav>
              <ul class="nav-links">
                  <li><a href="/1pagina civil/sitios/inicio.php">Inicio</a></li>
                  <li class="dropdown">
                    <a href="/1pagina civil/sitios/prod.php#Productos">Productos▾</a>
                    <div class="dropdown-content">
    
                      <a href="/1pagina civil/sitios/prod.php#acesorio">Acesorios</a>
                        <!-- Agregar el nuevo dropdown de camisas -->
                        <div class="dropdown-camisas">
                            <a href="/1pagina civil/sitios/prod.php#camisas">Ropa▾</a>
                            <div class="dropdown-camisas-content">
                                <a href="/1pagina civil/sitios/prod.php#camibuso" >Camibusos</a>
                                <a href="/1pagina civil/sitios/prod.php#camisas" >Camisas</a>
                                <a href="/1pagina civil/sitios/prod.php#pantalone">pantalones</a>
                            </div>
                        </div>
                        <a href="/1pagina civil/sitios/prod.php#bolsos">Bolsos</a>
                        <!-- Agregar el nuevo dropdown de estampados -->
                        <div class="dropdown-camisas">
                          <a href="/1pagina civil/sitios/prod.php#estampados">Estampados▾</a>
                          <div class="dropdown-estampados-content">
                              <a href="/1pagina civil/sitios/prod.php#estampados">Estampados</a>
                              <a href="/1pagina civil/sitios/prod.php#personalizado">Personalizados</a>
                          </div>
                      </div>
                      <!-- Agregar el nuevo dropdown de gorras -->
                      <div class="dropdown-camisas">
                        <a href="/1pagina civil/sitios/prod.php#gorra">Gorras▾</a>
                        <div class="dropdown-gorras-content">
                            <a href="/1pagina civil/sitios/prod.php#boina">Boinas</a>
                            <a href="/1pagina civil/sitios/prod.php#gorra">Gorras</a>
                            <a href="/1pagina civil/sitios/prod.php#pava">Pavas</a>
                            <a href="/1pagina civil/sitios/prod.php#cascos">casco</a>
                        </div>
                      </div>
                      <!-- Agregar el nuevo dropdown de Seguridad▾ -->
                        <a href="/1pagina civil/sitios/prod.php#promocion">Ofertas</a>
                    </div>
                  </li>
                  <li><a href="/1pagina civil/sitios/ubic.php">Ubicación</a></li>
                  <li><a href="/1pagina civil/sitios/cont.php">Contacto </a></li>
                  <li><a href="/1pagina civil/sitios/acer.php">Acerca de</a></li>
              </ul>
              <div class="toggle-button">
                  <span class="bar"></span>
                  <span class="bar"></span>
                  <span class="bar"></span>
              </div>
          </nav>
      </div>
    </header>  