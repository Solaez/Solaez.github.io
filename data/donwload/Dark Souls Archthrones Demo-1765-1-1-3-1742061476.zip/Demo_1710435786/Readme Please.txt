This document contains install instructions for the following languages: English, German, French, Italian, Japanese, Polish, Portuguese (Brazil), Russian, Spanish (Spain), Simplified Chinese, and Traditional Chinese.

Dieses Dokument enthält Installationsanweisungen für die folgenden Sprachen: Englisch, Deutsch, Französisch, Italienisch, Japanisch, Polnisch, Portugiesisch (Brasilien), Russisch, Spanisch, Chinesisch (vereinfacht) und Chinesisch (traditionell).

Ce document contient des étapes d'installation dans les langages suivants : Anglais, Allemand, Français, Italien, Japonais, Polonais, Portugais (Brésil), Russe, Espagnol (Espagne), Chinois simplifié et Chinois traditionnel.

Questo documento contiene le istruzioni di installazione per le seguenti lingue: inglese, tedesco, francese, italiano, giapponese, polacco, portoghese brasiliano, russo, spagnolo, cinese semplificato e cinese tradizionale.

以下の言語向けにインストールされる場合はこのファイルをご参照ください:
英語、日本語、フランス語、イタリア語、ドイツ語、スペイン語（スペイン向け）、ポーランド語、ロシア語、ポルトガル語（ブラジル向け）中国語（簡体字）、中国語（繁体字）

Ten dokument zawiera instrukcje instalacji w następujących językach: angielskim, niemieckim, francuskim, włoskim, japońskim, polskim, portugalskim brazylijskim, rosyjskim, hiszpańskim, chińskim uproszczonym i chińskim tradycyjnym.

Este documento contêm instruções de instalação para os seguintes idiomas: Inglês, Alemão, Francês, Italiano, Japonês, Polonês, Português Brasileiro, Russo, Espanhol, Chinês Simplificado e Chinês Tradicional.

В этом документе содержатся инструкции по установке на следующих языках: английский, немецкий, французский, итальянский, японский, польский, португальский (Бразилия), русский, испанский (Испания), упрощенный и традиционный китайский.

Este documento contiene instrucciones para la instalación en los siguientes idiomas: Inglés, Alemán, Francés, Italiano, Japonés, Polaco, Portugués (Brasil), Ruso, Español (España), Chino Simplificado y Chino Tradicional.

此文档内含以下语言的安装指南：
英语、德语、法语、意大利语、日语、波兰语、葡萄牙语、俄语、西班牙语、简体中文与繁体中文。

此文件內含以下語言的安裝指南：英文、德文，法文，意大利文，日文，波蘭文，葡萄牙文，俄文，西班牙文，簡體中文和繁體中文

###############################################################################

ENGLISH:

Archthrones Demo


This mod is shipped with Lazy Loader. The actual Archthrones dll is with the dllMods folder.

Install:
1. Ensure you have a freshly installed copy of Dark Souls III with both DLCs
1a. You can go into the properties of the game on Steam to validate

2.Copy the contents of this zip into the "Game" folder, this is the folder the DarkSoulsIII.exe can be found. 

3.Set the Game language to English in the Steam properties of Dark Souls III.
3a.More languages will be added as time goes on.

4.Enjoy. The dll will download the gamefiles from our download server so long as its not overloaded. If the server is unavailable you can manually download the files from NexusMods
4a. If your game repeatedly crashes, then you should downpatch your exe to 1.15. These are known physics bugs with 1.15.1 and 1.15.2.
Here are 2 ways to downpatch:
1: Download the 1.15 exe from here: https://soulsspeedruns.com/darksouls3/crash-fix
2: Use the Steam console: https://soulsspeedruns.com/darksouls3/downpatching

If you have manually downloaded the game files:
1.Create a folder named "archthrones" in the "Game" folder, this is the folder the DarkSoulsIII.exe can be found.

2.Extract the contents of the "archthrones.zip" into the folder so that the when it is complete it contains a folder named "_archthrones".


SteamDeck/Linux Users:
All other install instructions should work. you will need this command:

WINEDLLOVERRIDES="dinput8.dll=n,b" %command%

in the steam launch options and to select "Proton 7.0-6" under the compatibility tab

PS: The provided dll should work on any, including international versions, Valid Steam Copy of Dark Souls III version 1.15 and up. 

Please do not redistribute the mod or its files. Please direct those who want it to NexusMods.

###############################################################################

Deutsch:

Archthrones Demo


Diese Mod wird zusammen mit Lazy Loader zur Verfügung gestellt. Die eigentliche Archthrones .dll befindet sich im Ordner „dllMods“.

Installationsprozess:
1. Versichere dich, dass du eine neu installierte Kopie von Dark Souls III mit beiden DLCs auf deinem PC installiert hast.
1a. Dies kannst du in den Spieleigenschaften auf Steam überprüfen.

2. Kopiere den Inhalt dieser ZIP-Datei in den „Game“-Ordner, in dem sich die DarkSoulsIII.exe befindet.

3. Stelle die Sprache des Spiels in den Steam-Eigenschaften von Dark Souls III auf (hier die Sprache aus der Readme einfügen).
3a. Weitere Sprachen werden im Verlauf der Zeit hinzukommen.

4. Viel Spaß! Die .dll lädt jetzt die Spieldateien von unserem Download-Server herunter, sofern dieser nicht überlastet ist. Falls der Server nicht verfügbar sein sollte, kannst du die Dateien auch manuell über NexusMods herunterladen
4a. Wenn dein Spiel wiederholt abstürzt, versuche, deine .exe auf Version 1.15 zu aktualisieren. Dies kann durch bekannte Physik-Fehler der Versionen 1.15.1 und 1.15.2 verursacht werden.
Hier sind zwei Möglichkeiten, um einen Downpatch durchzuführen:
1: Lade die 1.15 .exe hier herunter: https://soulsspeedruns.com/darksouls3/crash-fix
2: Über die Steam-Konsole: https://soulsspeedruns.com/darksouls3/downpatching

Solltest du die Spieldateien manuell heruntergeladen haben:
1. Erstelle einen Ordner mit dem Namen „archthrones“ im Ordner „Game“, in dem sich die DarkSoulsIII.exe befindet.

2. Entpacke den Inhalt der Datei „archthrones.zip“ in diesen Ordner. Am Ende sollte nun ein Ordner mit dem Namen „_archthrones“ existieren.


Bei Verwendung eines SteamDeck/Linux-Betriebssystems:
Sämtliche bisherigen Installationsanweisungen sollten auch hier funktionieren, jedoch wird der folgende Befehl (in den Steam-Startoptionen) benötigt:

WINEDLLOVERRIDES="dinput8.dll=n,b" %command%

„Proton 7.0-6“ sollte im Menüpunkt „Kompatibilität“ ausgewählt sein.

PS: Die bereitgestellte .dll sollte auf jeder gültigen Steam-Kopie von Dark Souls III Version 1.15 (einschließlich der internationalen Versionen) und höher funktionieren.

Wir bitten darum, diese Mod oder die dazugehörigen Dateien nicht weiterzuverbreiten und interessierte Spieler:innen an NexusMods weiterzuleiten.

###############################################################################

Français:

Demo d'Archthrones


Ce mod inclus Lazy Loader. Le .dll d'Archthrones est dans le dossier dllMods.

Installation :
1. Assurez-vous de posséder une copie fraîchement installée de Dark Souls III et ses DLC.
1a. Vous pouvez aller dans les propriétés du jeu sur Steam pour confirmer cette étape.

2. Copiez le contenu de ce .zip dans le dossier "Game". C'est ici que l'on peut trouver DarkSoulsIII.exe.

3. Choisissez le langage "Français" dans les propriétés Steam de Dark Souls III.
3a. Davantage de langages seront ajoutés avec le temps.

"4. Amusez-vous ! Le .dll va télécharger les fichiers du jeu sur notre serveur de téléchargement si celui-ci n'est pas surchargé. 
Si le serveur est indisponible, vous pouvez télécharger les fichiers manuellement sur Nexus Mods."
4a. Si votre jeu crash à répétition, effectuez un downpatch de votre .exe vers la version 1.15. Il s'agit là de bugs de physiques liés à la 1.15.1 et 1.15.2.
Voici deux manières de downpatch votre jeu :
1 : Téléchargez le .exe en version 1.15 via ce lien : https://soulsspeedruns.com/darksouls3/crash-fix
2 : Utilisez la console Steam : https://soulsspeedruns.com/darksouls3/downpatching

Si vous avez téléchargé les fichiers du jeu manuellement : 
1. Créez un dossier appelé "archthrones" dans le dossier "Game", le même dossier dans lequel on trouve DarkSoulsIII.exe.

2. Extrayez le contenu de "archthrones.zip" dans ce nouveau dossier. A la fin de l'extraction, nous trouverons un dossier appelé "_archthrones" à l'intérieur.


Utilisateurs de Linux / Steam Deck :
Les autres instructions d'installation devraient fonctionner. Vous aurez besoin d'entrer la commande suivante :

WINEDLLOVERRIDES="dinput8.dll=n,b" %command%

dans les options de lancement de Steam et sélectionner "Proton 7.0-6" dans l'onglet compatibilité.

PS : Le .dll fourni devrait fonctionner sur n'importe quelle copie Steam valide de Dark Souls III ver. 1.15 et +, y compris les versions internationales.

Nous vous prions de ne pas redistribuer ce mod ou ses fichiers. Dirigez ceux souhaitant le télécharger vers Nexus Mods.

###############################################################################

Italiano

Archthrones Demo


Questa mod è rilasciata con Lazy Loader. La dll Archthrones effettiva è nella cartella dllMods.

Installazione:
1. Assicurati di avere una copia appena installata di Dark Souls III con entrambi i DLC
1a. Puoi andare nelle proprietà del gioco su Steam per confermare

2. Copia il contenuto di questo file zip nella cartella "Game", questa è la cartella in cui si trova DarkSoulsIII.exe.

3. Imposta la lingua del gioco su "Italiano" nelle proprietà di Steam di Dark Souls III.
3a.In futuro verranno aggiunte altre lingue.

4. Divertiti. La dll scaricherà i file di gioco dal tuo server di download, a patto che non sia sovraccarico. Se il server non è disponibile, puoi scaricare manualmente i file da NexusMods
4a. Se il tuo gioco crasha ripetutamente, dovresti installare una patch per il tuo exe alla versione 1.15. Questi sono bug della fisica noti con la 1.15.1 e la 1.15.2.
Ecco 2 modi per effettuare il downpatch:
1: Scarica l'exe 1.15 da qui: https://soulsspeedruns.com/darksouls3/crash-fix
2: Usa la console Steam: https://soulsspeedruns.com/darksouls3/downpatching

Se hai scaricato manualmente i file del gioco:
1. Crea una cartella chiamata "archthrones" nella cartella "Game". Questa è la cartella in cui si trova DarkSoulsIII.exe.

2. Estrai il contenuto di "archthrones.zip" nella cartella in modo che una volta completato contenga una cartella denominata "_archthrones".


Utenti SteamDeck/Linux:
Tutte le altre istruzioni di installazione dovrebbero funzionare. Avrai bisogno di questo comando:

WINEDLLOVERRIDES="dinput8.dll=n,b" %command%

nelle opzioni di avvio di Steam e selezionare "Proton 7.0-6" nella scheda compatibilità

PS: la dll fornita dovrebbe funzionare su qualsiasi copia Steam valida di Dark Souls III versione 1.15 e successive, comprese le versioni internazionali.

Per favore non ridistribuire la mod o i suoi file. Per favore indirizza chi la desidera a NexusMods.

###############################################################################

日本語:

Archthrones デモ版


このMODにはLazy Loaderが同梱されています。Archthronesのdllファイルは「dllMods」フォルダに格納されています。

インストール方法：
1. Dark Souls IIIとDLC2種をインストールしてください。他のMOD等が含まれないよう、新たにインストールすることをお勧めします。
1a. DLCがインストールされているかどうかは、Steamのライブラリ→Dark Souls III→「設定(歯車マーク)」→「プロパティ」から確認できます。

2. zipファイルを解凍した中身のファイルを「Game」フォルダ(DarkSoulsIII.exeがあるフォルダ)にコピーしてください。

3. Steamの「設定(歯車マーク)」→「プロパティ」から言語を「日本語」に設定してください。
3a. その他の言語は随時アップデートで追加される予定です。

"4. 「プレイ」を押してください。ファイルがArchthronesサーバーから自動でダウンロードされます。
サーバーが混雑しているなど、ダウンロードに時間がかかる、もしくは失敗する場合はNexus Modsから手動でのダウンロードをお試しください。"
4a. 何度試してもゲームがクラッシュする場合、DarkSoulsIII.exeファイルを1.15にバージョンダウンして再度お試しください。
バージョンダウンには以下の2通りの方法のどちらかをお試しください。
1: https://soulsspeedruns.com/darksouls3/crash-fix から1.15のファイルをダウンロードする
2: Steamのコンソールを利用する(https://soulsspeedruns.com/darksouls3/downpatching)

手動でファイルをダウンロードした場合:
1：Gameフォルダに「archthrones」フォルダを作成してください。

2：archthrones.zipの中身を「archthrones」フォルダへ解凍してください。「archthrones」フォルダ内に「_archthrones」というフォルダが作成されます。


SteamDeck/Linuxでプレイされる場合:
基本的には同じ手順で動作しますが、設定(歯車マーク)→プロパティ→「一般」の「起動オプション」に下記コマンドを入力してください。

WINEDLLOVERRIDES="dinput8.dll=n,b" %command%

また、「互換性」オプションで「Proton 7.0-6」を選択してください。

"備考:
dllファイルは、海外版を含む「Dark Souls III」Steam版、1.15以上のバージョンでのみ動作します。
MODや内部ファイルの二次配布は禁止とします。"

プレイを希望される方には、Nexus Modsからダウンロードをするようご案内をお願いいたします。

###############################################################################

Polski:

Wersja demonstracyjna Archthrones


Modyfikacja ma wbudowany Lazy Loader. Faktyczny plik „Archthrones.dll” znajduje się w folderze „dllMods”.

Instalacja:
1. Upewnij się, że masz świeżo zainstalowaną wersję Dark Souls III z obojgiem DLC.
1a. Możesz przejść do właściwości gry na Steam, aby sprawdzić spójność plików gry.

Skopiuj zawartość pobranego archiwum .zip do folderu „Game”, w którym znajduje się plik „DarkSoulsIII.exe”.

3. Ustaw język gry na polski w ustawieniach Dark Souls III na Steam.
3a. Z czasem będą dodawane kolejne języki.

4. Miłej gry. Plik dll pobierze pliki gry z naszego serwera, o ile nie będzie on przeciążony. Jeśli serwer będzie niedostępny, możesz ręcznie pobrać pliki z NexusMods.
4a. Jeśli gra regularnie się zawiesza/wyłącza, powinieneś przywrócić poprzednią wersję swojego pliku exe do 1.15. W wersjach 1.15.1 i 1.15.2 zaobserwowano problemy z fizyką.
Są na to dwa sposoby:
1: Pobierz plik „1.15 exe” ze strony: https://soulsspeedruns.com/darksouls3/crash-fix
2: Skorzystaj z konsoli Steam: https://soulsspeedruns.com/darksouls3/downpatching

Jeśli ręcznie pobrałeś pliki gry:
1. Stwórz folder o nazwie „Archthrones” w folderze „Game”, w którym znajduje się plik „DarkSoulsIII.exe”.

2. Wypakuj zawartość archiwum „archthrones.zip” do tego folderu, tak aby po zakończeniu znajdował się w nim folder o nazwie „_archthrones”.


Instrukcje dla użytkowników Linuxa/Steam Decka:
Wszystkie pozostałe instrukcje instalacji powinny działać. Będziesz potrzebować tego polecenia:

WINEDLLOVERRIDES="dinput8.dll=n,b" %command%

w opcjach uruchamiania Steam oraz wybrać „Proton 7.0-6” w zakładce zgodności

PS: Dostarczony plik dll powinien działać na każdej, legalnie zakupionej kopii gry Dark Souls III na wersji 1.15 i nowszej.

Proszę nie rozpowszechniać modyfikacji ani jej plików. Proszę przekierować zainteresowane osoby do strony NexusMods.

###############################################################################

Português Brasileiro:

Demo de Arquitronos


Este mod é distribuido com o Lazy Loader. A dll real do Arquitronos está na pasta dllMods.

Instalação:
1. Certifique-se de que você tenha uma cópia recém-instalada de Dark Souls III com ambas as DLCs.
1a. Você pode acessar as propriedades do jogo no Steam para validar.

2. Copie o conteúdo desse zip para a pasta "Game", essa é a pasta onde o DarkSoulsIII.exe pode ser encontrado.

3. Defina o idioma do Jogo como Português Brasileiro nas propriedades do Steam do Dark Souls III.
3a. Mais idiomas serão adicionados com o tempo.

4. Divirta-se. A dll fará o download dos arquivos do jogo do nosso servidor, contanto que ele não esteja sobrecarregado. Se o servidor não estiver disponível você pode baixar manualmente os arquivos no NexusMods.
4a. Se o jogo cair repetidamente, você terá que fazer o downpatch do .exe para a ver. 1.15. Esses são erros de física conhecidos nas ver. 1.15.1 e 1.15.2.
Aqui estão duas maneiras de fazer o downpatch:
1: Baixe o .exe da ver. 1.15 daqui: https://soulsspeedruns.com/darksouls3/crash-fix
2: Use o console da Steam: https://soulsspeedruns.com/darksouls3/downpatching

Se você baixou manualmente os arquivos do jogo:
1. Crie uma pasta chamada "archthrones" na pasta "Game", essa é a pasta onde o DarkSoulsIII.exe pode ser encontrado.

2. Extraia o conteúdo do "archthrones.zip" para a pasta, de modo que, quando concluído, ele contenha uma pasta chamada "_archthrones".


Usuários de SteamDeck/Linux:
Todas as outras instruções de instalação devem funcionar. Você vai precisar usar esse comando:

WINEDLLOVERRIDES="dinput8.dll=n,b" %command%

nas opções de inicialização do steam e selecionar "Proton 7.0-6" na guia de compatibilidade.

PS: A dll fornecida deve funcionar em qualquer cópia válida do Steam de Dark Souls III versão 1.15 ou superior, incluindo versões internacionais.

Por favor, não redistribua o mod ou seus arquivos. Direcione os usuários que quiserem o mod ao NexusMods.

###############################################################################

Русский:

Archthrones Демо


Этот мод поставляется с Lazy Loader. Фактический файл Archthrones dll находится в папке dllMods.

Установка:
1. Убедитесь, что у вас установлена свежая копия Dark Souls III с обоими дополнениями.
1a. Это вы можете проверить зайдя в свойства игры в Steam.

2. Скопируйте содержимое этого zip-архива в папку "Game", где находится файл DarkSoulsIII.exe.

3. Установите язык игры на (Русский) в свойствах Steam для Dark Souls III.
3a. Со временем будут добавлены новые языки.

4. Наслаждайтесь игрой. DLL загрузит игровые файлы с нашего сервера загрузки, если конечно он не перегружен. Если сервер недоступен, вы можете вручную скачать файлы с NexusMods.
4a. Если ваша игра постоянно вылетает, вам следует откатить exe. файл до версии 1.15.  Версиях 1.15.1 и 1.15.2. есть баги с физикой.
Вот 2 способа откатить версию:
1: Скачайте exe файл версии 1.15 отсюда: https://soulsspeedruns.com/darksouls3/crash-fix
2: Или используйте консоль Steam: https://soulsspeedruns.com/darksouls3/downpatching

Если вы вручную загрузили файлы игры:
1. Создайте папку с именем "archthrones" в папке "Game", где находится файл DarkSoulsIII.exe.

2. Извлеките содержимое файла "archthrones.zip" в  созданную папку так, чтобы после завершения в ней находилась папка с названием "_archthrones".


Для пользователей SteamDeck/Linux:
Все остальные инструкции по установке должны работать. Введите эту команду:

WINEDLLOVERRIDES="dinput8.dll=n,b" %command%

в параметрах запуска Steam, а так же выберите "Proton 7.0-6" во вкладке совместимости

PS: Предоставленная DLL должна работать на любой версии, включая международные и официальной Steam-копией Dark Souls III версии 1.15 и выше.

Пожалуйста, не распространяйте мод или его файлы своевольно. Направляйте желающих получить файлы на страницу мода в NexusMods.

###############################################################################

Español (España):

Demo de Arquitronos


Este mod incluye Lazy Loader. El archivo dll de Arquitronos se encuentra en la carpeta dllMods.

Instalación: 
1. Asegúrate de instalar una copia nueva de Dark Souls III con los dos contenidos descargables adicionales.
1a. Puedes entrar en las propiedades del juego en Steam y verificar la integridad de los archivos

2. Copia los contenidos de este zip dentro de la carpeta del juego, donde se encuentra el archivo DarkSoulsIII.exe

3. Cambia el idioma del juego a Español en las propiedades de Dark Souls III en Steam.
3a. Más idiomas serán añadidos en el futuro. 

4. ¡Que lo disfrutes! El dll descargará los archivos desde nuestro servidor siempre y cuando no esté saturado. Si el servidor no está disponible, puedes descargar los archivos manualmente desde NexusMods. 
4a. Si tu juego se cierra continuamente y saltan errores, deberías bajar a la versión 1.15 (downpatching). Hay algunos bugs en las físicas de las versiones 1.15.1 y 1.15.2.
Aquí hay 2 maneras de bajar de versión de parche:
1. Descarga el archivo exe de 1.15 desde aquí: https://soulsspeedruns.com/darksouls3/crash-fix
2. Usa el menú de Steam: https://soulsspeedruns.com/darksouls3/downpatching

Si has descargado los archivos manualmente:
1. Crea una carpeta llamada "archthrones" en la carpeta "Game" donde se encuentra el ejecutable de Dark Souls III, DarkSoulsIII.exe 

2. Extrae los contenidos de "archthrones.zip" dentro de la carpeta, para que tenga una carpeta dentro llamada "_archthrones".


Usuarios de SteamDeck/Linux:
Las instrucciones anteriores deberían funcionar. Necesitarás este comando

WINEDLLOVERRIDES="dinput8.dll=n,b" %command%

en las opciones de lanzamiento de Steam, y selecciona "Proton 7.0-6" en la pestaña de compatibilidad

PD: El dll proporcionado debería funcionar en cualquier versión (incluyendo las internacionales) válida de Dark Souls III 1.15 y seguidas.

Por favor, no redistribuyas el mod o sus archivos. Puedes dirigir a los que quieran jugar a nuestra página en NexusMods.

###############################################################################

简体中文:

《远古王座》Demo版本


本模组为延迟安装器。实际的Archthrones dll位于dllMods文件夹里。

安装：
1. 确保你已安装最新版《黑暗之魂3》且解锁两个DLC
1a. 你可以前往Steam库的“属性”界面验证

2. 复制此zip文件的内容至“Game”文件夹中，即DarkSoulsIII.exe所在的文件夹。

3. 在《黑暗之魂3》的Steam“属性”界面中，将游戏语言设置为简体中文。
3a. 更多语言将于随后推出。

4. 启动游戏。该dll文件会从我们的下载服务器进行游戏文件的下载（未维护期间）。如果服务器不可用，你也可以手动从NexusMods下载文件。
4a. 如果你的游戏反复崩溃，你需要将游戏exe降至1.15版本。目前1.15.1与1.15.2存在已知物理问题。
有两种下载办法：
1. 点此下载1.15版exe：https://soulsspeedruns.com/darksouls3/crash-fix
2. 使用Steam控制台：https://soulsspeedruns.com/darksouls3/downpatching

如果你已手动下载游戏文件：
1. 在“Game”文件夹下（即DarkSoulsIII.exe所在的文件夹）创建名为“archthrones”的文件夹。

2. 将“archthrones.zip”文件内容解压至该文件夹，完成后应该会在其中出现名为“_archthrones”的文件夹。


SteamDeck/Linux用户：
其他安装指南应该均有效。你还需要以下指令：

WINEDLLOVERRIDES="dinput8.dll=n,b" %command%

在Steam启动选项中加入此指令，并在兼容性选项卡中选择“Proton 7.0-6”

附：所提供的dll文件可在任何版本（包括国际版）的1.15及以上版本的《黑暗之魂3》有效Steam副本中运行。

请勿转发本模组或其文件。请将需要者引导至NexusMods。

###############################################################################

繁體中文:

《遠古王座》Demo版本


本模組為延遲安裝器。實際的Archthrones dll位於dllMods文件夾裡。

安裝：
1. 確保你已安裝最新版《黑暗靈魂3》且解鎖兩個DLC
1a. 你可以前往Steam庫游戲的「屬性」(properties) 介面驗證

2. 將此zip文件的內容複製到「Game」文件夾中，即DarkSoulsIII.exe所在的文件夾。

3. 在《黑暗靈魂3》的Steam「屬性」介面中，將遊戲語言設定為繁體中文。
3a. 更多語言將於隨後推出。

4. 啟動遊戲。該dll檔案會從我們的下載伺服器進行遊戲文件的下載（未維護期間）。如果伺服器不可用，你也可以手動從NexusMods下載文件
4a. 如果你的遊戲反覆崩潰，你需要將遊戲exe降到1.15版本。目前1.15.1與1.15.2存在已知物理問題。
有两种下降版本的办法：
1. 點此下載1.15版exe：https://soulsspeedruns.com/darksouls3/crash-fix
2. 使用Steam控制台：https://soulsspeedruns.com/darksouls3/downpatching

如果你已手動下載遊戲檔案：
1. 在「Game」文件夾下（即DarkSoulsIII.exe所在的文件夾）建立名為「archthrones」的文件夾。

2. 將「archthrones.zip」檔案內容解壓縮至該資料夾，完成後應該會出現一個名為「_archthrones」的文件夾。


SteamDeck/Linux用戶：
其他安裝指南應該都有效。你還需要以下指令：

WINEDLLOVERRIDES="dinput8.dll=n,b" %command%

在Steam啟動選項中加入此指令，並在相容性標籤中選擇“Proton 7.0-6”

附注：所提供的dll檔案可在任何版本（包括國際版）的1.15以上版本的《黑暗靈魂3》有效Steam副本中運行。

請勿轉送本模組或其檔案。請將需要者引導至NexusMods。