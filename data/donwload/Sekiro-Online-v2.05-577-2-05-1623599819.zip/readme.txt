A mod that adds unofficial PvP and co-op features to the game.

As with all FromSoftware games, Sekiro is a unique experience; What gives the game an entirely different feel to previous is the lack of an online mode, this mod aims to emulate that to the best of my ability.

This is a pet project that I decided to release, if you don't like the idea of online play in Sekiro, you don't have to play. I didn't create this mod because I strongly believed that the game needed online, just that it sounded like fun.

If you enjoy my mods, and would like to support me, you can buy me a coffee here: https://ko-fi.com/lukeyui

There is also a discord for the mod, feel free to join and have a chat: https://discord.gg/7zNSyRS

What is it?

As the title suggests, this mod adds both PvP and co-operative play to the game - I've tried to make it as familiar as I can to Souls games' online mode, but as I'm not a professional game development company, it's not going to be exactly the same.

The mod itself runs purely on P2P connections. There is a server, however this is only used for the "summon signs"

Difference to the beta version

The mod has been out in beta for a while now. Thank you for all of your feedback/bug reports, I've completely reworked the mod from the ground up, and now I'm much happier with the way that the mod plays, most notably:
The net code is much more efficient, and latency is reduced.
Sessions are much more stable
PvP combat is improved, and I've created some custom mechanics to make it more interesting (e.g. Mikiri counters on other players)
PvE combat is vastly improved, enemy movement and actions are much smoother, and uses a degree of client prediction
World sync is complete, if you invade someone in a different world state (e.g. Burning Ashina) it'll load the area and enemies correctly.
Events in your world no longer synchronise with the hosts world.

Features/Details:

Support for up to 250 players  | Capped at 6 for now (1 host + 5 phantoms)
PvP and invasions with simple matchmaking.
Co-op with friends, with fully functional world, event, and enemy sync.
You can't pause the game.
Tutorial prompts and item popups are disabled
Minimal graphical interface, giving you basic mod information (connected players, ping, etc.)
A central server (subject to availability) which allows you to summon other people into your world with summon signs.

When the mod updates, older versions will be unsupported. (e.g. you can't use v1.00, and match with someone playing v1.01)

Instructions:

There are a few key items for playing online
Cursed Emblem
Demon Eyes
Coward's Bell
Spirit Essence
Vengeful Spirit
Serendipitous Spirit

You can play online anywhere, and join anyone. There are no matchmaking rules, and there are no area/location restrictions. Players will be scaled up/down to your local player's level, and PvP damage is normalised.

If you're using the version with the overlay, press F1 to access the mod's menu.

To play:
Create (host) a session -  Use the "Cursed Emblem" item. Once you've done this, you cannot stop hosting until you either quit or die.
Invade a session -  Use the "Demon Eyes" item
Co-op - The host will need to create a session, then invite you to their game through the steam friends list. Alternatively you can use the Vengeful Spirit to invite dark spirits into your world, or the Serendipitous Spirit to invite phantoms into your world.
Leave - Use the "Coward's Bell" item, or die.