
  //1 producto de inicio
  window.addEventListener('DOMContentLoaded', () => {
    const urlFragment = window.location.hash.slice(1);
    if (urlFragment === 'CB001') {
      const selectButton = document.querySelector('.product[id="CB001"] button');
      if (selectButton) {
        selectButton.click();
      }
    }
  });
  //2 producto de inicio
  window.addEventListener('DOMContentLoaded', () => {
    const urlFragment = window.location.hash.slice(1);
    if (urlFragment === 'CB002') {
      const selectButton = document.querySelector('.product[id="CB002"] button');
      if (selectButton) {
        selectButton.click();
      }
    }
  });
  //3 producto de inicio
  window.addEventListener('DOMContentLoaded', () => {
    const urlFragment = window.location.hash.slice(1);
    if (urlFragment === 'CB003') {
      const selectButton = document.querySelector('.product[id="CB003"] button');
      if (selectButton) {
        selectButton.click();
      }
    }
  });
  //4 producto de inicio
  window.addEventListener('DOMContentLoaded', () => {
    const urlFragment = window.location.hash.slice(1);
    if (urlFragment === 'B001') {
      const selectButton = document.querySelector('.product[id="B001"] button');
      if (selectButton) {
        selectButton.click();
      }
    }
  });
  //5 producto de inicio
  window.addEventListener('DOMContentLoaded', () => {
    const urlFragment = window.location.hash.slice(1);
    if (urlFragment === 'C001') {
      const selectButton = document.querySelector('.product[id="C001"] button');
      if (selectButton) {
        selectButton.click();
      }
    }
  });
  //6 producto de inicio
  window.addEventListener('DOMContentLoaded', () => {
    const urlFragment = window.location.hash.slice(1);
    if (urlFragment === 'BD001') {
      const selectButton = document.querySelector('.product[id="BD001"] button');
      if (selectButton) {
        selectButton.click();
      }
    }
  });
  //7 producto de inicio
  window.addEventListener('DOMContentLoaded', () => {
    const urlFragment = window.location.hash.slice(1);
    if (urlFragment === 'BD002') {
      const selectButton = document.querySelector('.product[id="BD002"] button');
      if (selectButton) {
        selectButton.click();
      }
    }
  });
  //8 producto de inicio
  window.addEventListener('DOMContentLoaded', () => {
    const urlFragment = window.location.hash.slice(1);
    if (urlFragment === 'BD003') {
      const selectButton = document.querySelector('.product[id="BD003"] button');
      if (selectButton) {
        selectButton.click();
      }
    }
  });
  //9 producto de inicio
  window.addEventListener('DOMContentLoaded', () => {
    const urlFragment = window.location.hash.slice(1);
    if (urlFragment === 'G001') {
      const selectButton = document.querySelector('.product[id="G001"] button');
      if (selectButton) {
        selectButton.click();
      }
    }
  });
  //10 producto de inicio
  window.addEventListener('DOMContentLoaded', () => {
    const urlFragment = window.location.hash.slice(1);
    if (urlFragment === 'CS001') {
      const selectButton = document.querySelector('.product[id="CS001"] button');
      if (selectButton) {
        selectButton.click();
      }
    }
  });