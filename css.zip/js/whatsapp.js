function toggle() {
    var element = document.getElementById("button");
    element.classList.toggle("wa__active");
    element.classList.toggle("wa__lauch");
 }



 //--------------------------------------------------------------------------